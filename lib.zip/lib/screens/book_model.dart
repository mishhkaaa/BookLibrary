class Book {
  final String title;
  final String summary;

  Book({
    required this.title,
    required this.summary,
  });
}
